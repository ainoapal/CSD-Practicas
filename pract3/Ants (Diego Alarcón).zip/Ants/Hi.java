
/**
 * New ant arrives to Terrain
 * 
 * @author CSD Juansa Sendra
 * @version 2021
 */
public class Hi extends Op {
    public Pos p; 
    public Hi(int a, Pos p)  {super(a); this.p=p;}
    public String toString() {return super.toString()+" Hi "+p;}
}
