import java.util.concurrent.locks.*;

/**
 * General monitor based Terrain
 * Only one condition
 * 
 * @author Diego Alarcón
 * @version 2021
 */
public class Terrain1 implements Terrain {
    Viewer v;
    Condition ocupada;
    ReentrantLock lock;
    public  Terrain1 (int t, int ants, int movs) {
        v=new Viewer(t,ants,movs,"1.- general monitor, one condition");
        lock = new ReentrantLock();
        ocupada = lock.newCondition();
        for (int i=0; i<ants; i++) new Ant(i,this,movs).start();
    }
    public  void     hi      (int a) {
        lock.lock();
        try {
            v.hi(a);
        } finally { lock.unlock(); }
    }
    public  void     bye     (int a) {
        lock.lock();
        try {
            v.bye(a); 
            ocupada.signalAll();
        } finally { lock.unlock(); }   
    }
    public  void     move    (int a) throws InterruptedException {
        lock.lock();
        try {
            v.turn(a); Pos dest=v.dest(a); 
            while (v.occupied(dest)) {ocupada.await(); v.retry(a);}
            v.go(a); ocupada.signalAll();
        } finally { lock.unlock(); }   
    }
}