
/**
 * Ant completes movement
 * 
 * @author CSD Juansa Sendra 
 * @version 2021
 */
public class Go extends Op {       
        public Go(int a) {super(a);}
    public String toString() {return super.toString()+" Go";}
}