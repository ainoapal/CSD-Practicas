
/**
 * Ant leaves Terrain
 * 
 * @author CSD Juansa Sendra 
 * @version 2021
 */
public class Bye extends Op {
    public Bye(int a)         {super(a);}
    public String toString() {return super.toString()+" Bye";}
}