import java.util.concurrent.locks.*;

/**
 * General monitor based Terrain
 * One condition per cell
 * 
 * @author Diego Alarcón
 * @version 2021
 */
public class Terrain2 implements Terrain {
    Viewer v;
    Condition [][] ocupada;
    ReentrantLock lock;
    public  Terrain2 (int t, int ants, int movs) {
        v=new Viewer(t,ants,movs,"2.- general monitor, multiple conditions");
        lock = new ReentrantLock();
        ocupada = new Condition [t][t];
        for (int i = 0; i < t; i++) {
            for (int j = 0; j < t; j++) {
                ocupada[i][j] = lock.newCondition();
            }
        }
        for (int i=0; i<ants; i++) new Ant(i,this,movs).start();
    }
    public  void     hi      (int a) {
        lock.lock();
        try {
            v.hi(a);
        } finally { lock.unlock(); }
    }
    public  void     bye     (int a) {
        lock.lock();
        try {
            Pos act=v.getPos(a); 
            v.bye(a);
            ocupada[act.x][act.y].signalAll();
        } finally { lock.unlock(); }   
    }
    public  void     move    (int a) throws InterruptedException {
        lock.lock();
        try {
            Pos act=v.getPos(a); 
            v.turn(a); 
            Pos dest=v.dest(a); 
            while (v.occupied(dest)) {
                ocupada[dest.x][dest.y].await(); 
                v.retry(a);
            }
            v.go(a); 
            ocupada[act.x][act.y].signalAll();
        } finally { lock.unlock(); }   
    }
}