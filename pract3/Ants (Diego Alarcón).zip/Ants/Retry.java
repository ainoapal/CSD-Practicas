
/**
 * Ant retries a movement
 * 
 * @author CSD Juansa Sendra
 * @version 2021
 */
public class Retry extends Op {       
    public Retry(int a)         {super(a);}
    public String toString() {return super.toString()+" Retry";}
}